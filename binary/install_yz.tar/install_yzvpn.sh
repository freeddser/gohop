#!/bin/bash
echo "install yzvpn for ubuntu16"
mkdir -p /etc/yzvpn
cp client.ini /etc/yzvpn/
cp server.ini /etc/yzvpn/
cp yzvpn /usr/local/bin/yzvpn
chmod a+x /usr/local/bin/yzvpn 
#configure systemctl
mkdir -p /usr/lib/systemd/system
cp yzvpn.service /usr/lib/systemd/system/
cp yzvpnclient.service /usr/lib/systemd/system/
chmod 754 /usr/lib/systemd/system/yzvpn*.service
echo "install yzvpn done"
echo "On server instance:"
echo "systemctl start yzvpn"
echo "On client instance:"
echo "systemctl start yzvpnclient"
